<!DOCTYPE html>
<html lang="sv">
    <head>
        <meta charset="utf-8"/>
        <title>php20</title>
    </head>
    <body>
        <h1>Mallsida i HTML</h1>
        <?php echo "<p>Hello World from PHP.</p>"; ?>
        <hr>
    </body>
</html>